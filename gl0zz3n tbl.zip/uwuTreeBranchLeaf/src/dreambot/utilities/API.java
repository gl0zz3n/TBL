package dreambot.utilities;

public class API {

    public static String currentBranch = "";
    public static String currentLeaf = "";

}
