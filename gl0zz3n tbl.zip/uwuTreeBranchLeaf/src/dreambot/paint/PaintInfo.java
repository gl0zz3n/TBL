package dreambot.paint;

public interface PaintInfo {
    String[] getPaintInfo();
}
